package calculator;

import javax.swing.*;
import java.awt.*;

public class DisplayPanel extends JPanel {
    private final JTextField displayField = new JTextField();
    private final JTextArea historyArea = new JTextArea(5, 20);
    private final HistoryManager historyManager;
    // initialize the memoryIndicator here:
    private final JLabel memoryIndicator = new JLabel("M");

    public DisplayPanel() {
        setLayout(new BorderLayout(5, 5));

        
        JPanel top = new JPanel(new BorderLayout());
        displayField.setEditable(false);
        displayField.setHorizontalAlignment(JTextField.RIGHT);
        top.add(displayField, BorderLayout.CENTER);

        // configure memory indicator (hidden by default)
        memoryIndicator.setFont(memoryIndicator.getFont().deriveFont(Font.BOLD, 12f));
        memoryIndicator.setVisible(false);
        top.add(memoryIndicator, BorderLayout.WEST);

        add(top, BorderLayout.NORTH);

        // CENTER: history
        historyArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(historyArea,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);

        historyManager = new HistoryManager(historyArea);
    }

    public void updateDisplay(String text) {
        displayField.setText(text);
    }

    public String getDisplayText() {
        return displayField.getText();
    }

    public void addToHistory(String expr, String result) {
        historyManager.addHistory(expr, result);
    }

    public void clearHistory() {
        historyManager.clearHistory();
    }

   
    public void showMemoryIndicator(boolean visible) {
        memoryIndicator.setVisible(visible);
    }
}
