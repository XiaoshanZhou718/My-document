package calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Arrays;  // add at the top of the file

public class Buttons extends JPanel {
    private final DisplayPanel display;
    private final CalculatorLogic logic = new CalculatorLogic();

   public Buttons(DisplayPanel display) {
    this.display = display;
    setLayout(new GridLayout(6, 4, 4, 4));

    String[] labels = {
        "MC", "MR", "MS", "M+",
        "M-", "C",  "CE", "%",
        "7",  "8",  "9",  "/",
        "4",  "5",  "6",  "*",
        "1",  "2",  "3",  "-",
        "0",  ".",  "+/-","="
    };

    // ─── DEBUG: print out what buttons we're adding ─────────────────
    System.out.println("Buttons labels = " + Arrays.toString(labels));
    // ────────────────────────────────────────────────────────────────

    ActionListener listener = e -> onButton(((JButton)e.getSource()).getText());
    for (String lbl : labels) {
        JButton button = new JButton(lbl);
        button.addActionListener(listener);
        add(button);
    }
}

    private void onButton(String cmd) {
        // Debug: print every button press
       System.out.println("🔍 Button pressed: [" + cmd + "]");

        String cur = display.getDisplayText();
        switch (cmd) {
            case "C":
                display.updateDisplay("");
                break;
            case "CE":
                display.updateDisplay("");
                break;
            case "%":
                if (!cur.isEmpty()) {
                    try {
                        double value = Double.parseDouble(cur);
                        display.updateDisplay(Double.toString(value / 100));
                    } catch (NumberFormatException e) {
                        display.updateDisplay("Error");
                    }
                }
                break;
            case "+/-":
                if (!cur.isEmpty()) {
                    display.updateDisplay(
                        cur.startsWith("-") ? cur.substring(1) : "-" + cur
                    );
                }
                break;

            case "MS":
                try {
                    double v = Double.parseDouble(cur);
                    logic.storeMemory(v);
                    display.showMemoryIndicator(true);
                } catch (NumberFormatException e) {
                    display.updateDisplay("Error");
                }
                break;

           case "MR":
    System.out.println("    → Entered MR branch; memory = " + logic.recallMemory());
    display.updateDisplay(Double.toString(logic.recallMemory()));
    break;


            case "M+":
                try {
                    double v2 = Double.parseDouble(cur);
                    logic.addToMemory(v2);
                    display.showMemoryIndicator(true);
                } catch (NumberFormatException e) {
                    display.updateDisplay("Error");
                }
                break;

            case "M-":
                try {
                    double v3 = Double.parseDouble(cur);
                    logic.subtractFromMemory(v3);
                    display.showMemoryIndicator(true);
                } catch (NumberFormatException e) {
                    display.updateDisplay("Error");
                }
                break;

            case "MC":
                logic.clearMemory();
                display.showMemoryIndicator(false);
                break;

            case "=":
                String result = logic.evaluate(cur);
                display.addToHistory(cur, result);
                display.updateDisplay(result);
                break;

            default:
                display.updateDisplay(cur + cmd);
        }
    }
}
