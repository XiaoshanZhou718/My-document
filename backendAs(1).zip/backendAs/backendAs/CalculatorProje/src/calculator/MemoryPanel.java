
package calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MemoryPanel extends JPanel {
    private double memory = 0.0;
    private final DisplayPanel display;

    public MemoryPanel(DisplayPanel display) {
        this.display = display;
        setLayout(new GridLayout(5, 1, 4, 4));
        for (String label : new String[]{"MC","MR","MS","M+","M-"}) {
            JButton b = new JButton(label);
            b.addActionListener(this::onMemory);
            add(b);
        }
    }

    private void onMemory(ActionEvent e) {
        String cmd = ((JButton)e.getSource()).getText();
        String cur = display.getDisplayText();
        double val = 0;
        try {
            val = Double.parseDouble(cur);
        } catch (NumberFormatException ex) {
            display.updateDisplay("Error");
            return;
        }
        switch (cmd) {
            case "MC": memory = 0; break;
            case "MR":
                display.updateDisplay(Double.toString(memory));
                return;
            case "MS": memory = val; break;
            case "M+": memory += val; break;
            case "M-": memory -= val; break;
        }
        display.updateDisplay("M=" + memory);
    }
}
