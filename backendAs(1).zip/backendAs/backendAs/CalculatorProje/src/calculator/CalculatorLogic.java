
package calculator;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class CalculatorLogic {
    private ScriptEngine engine;

     private double memory = 0.0;

    public CalculatorLogic() {
        engine = new ScriptEngineManager()
                     .getEngineByName("JavaScript");
        try {
            // Define scientific functions (input in degrees for trig functions)
            engine.eval("function sin(x){ return Math.sin(x * Math.PI/180); }");
            engine.eval("function cos(x){ return Math.cos(x * Math.PI/180); }");
            engine.eval("function tan(x){ return Math.tan(x * Math.PI/180); }");
            // Base-10 logarithm
            engine.eval("function log(x){ return Math.log(x) / Math.log(10); }");
        } catch (ScriptException e) {
            // Initialization errors
            e.printStackTrace();
        }
    }

    public String evaluate(String expr) {
        try {
            Object result = engine.eval(expr);
            return result.toString();
        } catch (ScriptException ex) {
            return "Error";
        }
    }
    // ── New memory methods ────────────────────────────

    /** Store the given value into memory (MS). */
    public void storeMemory(double val) {
        memory = val;
    }

    /** Recall the current memory value (MR). */
    public double recallMemory() {
        return memory;
    }

    /** Add the given value to memory (M+). */
    public void addToMemory(double val) {
        memory += val;
    }

    /** Subtract the given value from memory (M−). */
    public void subtractFromMemory(double val) {
        memory -= val;
    }

    /** Clear memory (MC). */
    public void clearMemory() {
        memory = 0.0;
    }
    // ──────────────────────────────────────────────────
}