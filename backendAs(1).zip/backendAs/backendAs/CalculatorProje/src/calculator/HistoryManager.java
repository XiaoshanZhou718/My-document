package calculator;

import javax.swing.JTextArea;
import java.util.ArrayList;
import java.util.List;

public class HistoryManager {
    private List<String> history = new ArrayList<>();
    private JTextArea historyArea;

    public HistoryManager(JTextArea historyArea) {
        this.historyArea = historyArea;
    }

    public void addHistory(String expression, String result) {
        String record = expression + " = " + result;
        history.add(0, record);
        
        if (history.size() > 10) {
            history.remove(history.size() - 1);
        }
        
        updateHistoryDisplay();
    }

    public void clearHistory() {
        history.clear();
        updateHistoryDisplay();
    }

    private void updateHistoryDisplay() {
        StringBuilder sb = new StringBuilder("Calculate history:\n");
        for (String record : history) {
            sb.append(record).append("\n");
        }
        historyArea.setText(sb.toString());
    }
}