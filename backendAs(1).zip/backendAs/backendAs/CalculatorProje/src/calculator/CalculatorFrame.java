
package calculator;

import javax.swing.*;
import java.awt.*;

public class CalculatorFrame extends JFrame {
    public CalculatorFrame() {
        super("My Calculator");
        initializeComponents();
        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }


    private void initializeComponents() {
        setLayout(new BorderLayout(5, 5));
        DisplayPanel display = new DisplayPanel();
        add(display, BorderLayout.NORTH);
        add(new Buttons(display), BorderLayout.CENTER);
       add(new ScientificFunctions(display), BorderLayout.WEST);
    }
}
