
package calculator;

public class InputValidator {
   
    public static boolean isValid(String expr) {
        int balance = 0;
        String ops = "+-*/%";
        char prev = '\0';

        for (int i = 0; i < expr.length(); i++) {
            char c = expr.charAt(i);

            if (c == '(') {
                balance++;
            } else if (c == ')') {
                balance--;
                if (balance < 0) return false;
            } else if (ops.indexOf(c) >= 0) {
                // two binary ops in a row?
                if (i == 0 && c != '-') return false;   
                if (prev != '\0' && ops.indexOf(prev) >= 0) return false;
            } else if (!Character.isDigit(c) && c != '.' && !Character.isLetter(c)) {
                return false;
            }
            prev = c;
        }

        return balance == 0 && ops.indexOf(prev) < 0;  
    }
}
