package calculator;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ScientificFunctions extends JPanel {
    private DisplayPanel display;

    public ScientificFunctions(DisplayPanel display) {
        this.display = display;
        setLayout(new GridLayout(6, 1));

        String[] sciTexts = {"sin", "cos", "tan", "log", "(", ")"};
        for (String text : sciTexts) {
            JButton btn = new JButton(text);
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String cmd = ((JButton) e.getSource()).getText();
                    display.updateDisplay(display.getDisplayText() + cmd);
                }
            });
            add(btn);
        }
    }
}