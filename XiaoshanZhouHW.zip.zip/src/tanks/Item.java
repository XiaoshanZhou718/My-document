package tanks;

public class Item {
    private String material;
    private double volumeGallons;
    private double density;
    // decimalism
    private double riskFactor;

    public Item(String material, double volumeGallons, double density, double riskFactor) {
        this.material = material;
        this.volumeGallons = volumeGallons;
        this.density = density;
        this.riskFactor = riskFactor;
    }

    public String getMaterial() {
        return material;
    }

    public double getVolumeGallons() {
        return volumeGallons;
    }

    public double getDensity() {
        return density;
    }

    public double getRiskFactor() {
        return riskFactor;
    }

    public double calculateVolume() {
        return volumeGallons * 0.00378541;
    }

    public double calculateWeight() {
        return volumeGallons * density;
    }

    public void printItem() {
        double volumeCubicMeters = calculateVolume();
        double weight = calculateWeight();
        System.out.printf("Item: %s, Volume=%.2f gal (%.2f m3), Weight=%.2f%n",material, volumeGallons, volumeCubicMeters, weight);
    }
}