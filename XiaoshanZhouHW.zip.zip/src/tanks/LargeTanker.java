package tanks;

public class LargeTanker extends Truck {
    public LargeTanker() {
        super(860, 52);
    }
}