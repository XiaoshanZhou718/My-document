package tanks;

public abstract class Truck {
    private double lengthInches;
    private double radiusInches;

    protected Truck(double lengthInches, double radiusInches) {
        this.lengthInches = lengthInches;
        this.radiusInches = radiusInches;
    }

    public double getLengthInches() {
        return lengthInches;
    }

    public double getRadiusInches() {
        return radiusInches;
    }

    public double calculateVolume() {
        double volumeCubicInches = Math.PI * radiusInches * radiusInches * lengthInches;
        //The unit is converted to cubic meters
        //1 inch = 0.0254 meter 1 cubic inch = 0.0254 ³ = 0.0254 × 0.0254 × 0.0254 
        return volumeCubicInches * 0.0000163871;
    }

    public void printTankerInfo() {
        System.out.printf(
            "Tanker: %s, Capacity=%.2f m3%n",
            this.getClass().getSimpleName(), 
            calculateVolume()
        );
    }
}