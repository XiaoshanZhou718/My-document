package tanks;

public class MediumTanker extends Truck {
    public MediumTanker() {
        super(380, 40);
    }
}