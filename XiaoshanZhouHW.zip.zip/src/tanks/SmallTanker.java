package tanks;

public class SmallTanker extends Truck {
    public SmallTanker() {
        super(300, 24);
    }
}