package main;

import calculation.Calculation;
import tanks.Item;
import Info.Info;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your order (e.g., O2 3200 Berlin):");

        if (scanner.hasNext()) {
            String material = scanner.next();
            if (scanner.hasNextDouble()) {
                double volume = scanner.nextDouble();
                if (scanner.hasNext()) {
                    String city = scanner.next();

                    double density;
                    switch (material) {
                        case "O2":
                            density = 1.429;
                            break;
                        case "H2":
                            density = 0.0899;
                            break;
                        case "N2":
                            density = 1.2506;
                            break;
                        case "Propene":
                            density = 2.009;
                            break;
                        case "CO2":
                            density = 1.977;
                            break;
                        case "Methane":
                            density = 0.717;
                            break;
                        case "Benzene":
                            density = 0.879;
                            break;
                        case "Water":
                            density = 8.345;
                            break;
                        case "Milk":
                            density = 8.6;
                            break;
                        default:
                            density = 1.0;
                            break;
                    }

                    double risk;
                    switch (material) {
                        case "O2":
                            risk = 0.17;
                            break;
                        case "H2":
                            risk = 0.18;
                            break;
                        case "N2":
                            risk = 0.02;
                            break;
                        case "Propene":
                            risk = 0.20;
                            break;
                        case "CO2":
                            risk = 0.10;
                            break;
                        case "Methane":
                            risk = 0.18;
                            break;
                        case "Benzene":
                            risk = 0.20;
                            break;
                        case "Water":
                        case "Milk":
                            risk = 0.0;
                            break;
                        default:
                            risk = 0.0;
                            break;
                    }

                    Calculation calculation = new Calculation();
                    calculation.addItems(new Item(material, volume, density, risk));
                    calculation.addOrder(city);

                    Info info = new Info("Xiaoshan Zhou", "31740706", "B", "2025-06-15", 351);
                    info.printInfo();

                    calculation.printItem();
                    calculation.printOrder();
                    calculation.bestShipping();
                    System.out.printf("Shipping Price: %.2f Euro%n", calculation.shippingPrice());

                } else {
                    System.err.println("Error: City name is missing.");
                }
            } else {
                System.err.println("Error: Volume must be a valid number.");
            }
        } else {
            System.err.println("Error: Invalid input format.");
        }

        scanner.close();
    }
}