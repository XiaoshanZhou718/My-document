package distance;

import java.util.HashMap;
import java.util.Map;

public class Distance {
    private Map<String, Double> distances = new HashMap<>();

    public Distance() {
        distances.put("Berlin", 288.0);
        distances.put("Munich", 776.0);
        distances.put("Leipzig", 350.0);
        distances.put("Dresden", 455.0);
        distances.put("Köln", 430.0);
        distances.put("Rome", 1381.0);
        distances.put("Paris", 893.0);
        distances.put("Wien", 966.0);
        distances.put("Madrid", 2110.0);
    }

    public double getDistance(String city) {
        return distances.getOrDefault(city, 0.0);
    }
}