package calculation;

import java.util.ArrayList;
import java.util.List;

import distance.Distance;
import tanks.Item;
import tanks.LargeTanker;
import tanks.MediumTanker;
import tanks.SmallTanker;

public class Calculation {
    private List<Item> items = new ArrayList<>();
    
    private String destination;

    public void addItems(Item item) {
        items.add(item); //Add transportation info
    }

    public void addOrder(String destination) {
        this.destination = destination;
    }

    public double totalVolume() {
        double total = 0;
        // Traverse all the transported items
        for (Item item : items) {
            total += item.calculateVolume();
        }
        return total;
    }

    public double totalWeight() {
        double total = 0;
        for (Item item : items) {
            total += item.calculateWeight();
        }
        return total;
    }

    public void printItem() {
        for (Item item : items) {
            item.printItem();
        }
    }

    public void printOrder() {
        double totalVol = totalVolume();
        double totalWeight = totalWeight();
        
        System.out.printf(
            "Destination: %s, Total Volume=%.2f m3, Total Weight=%.2f%n",
            destination, totalVol, totalWeight
        );
    }

    public void bestShipping() {
        double totalVol = totalVolume();
        
        double largeCap = new LargeTanker().calculateVolume();
        double mediumCap = new MediumTanker().calculateVolume();
        double smallCap = new SmallTanker().calculateVolume();

        // Distribute and calculate how many large, medium and small transport vehicles are needed
        int largeCount = 0;
        int mediumCount = 0;
        int smallCount = 0;

        // Large first
        if (largeCap > 0) { // notice 0
            largeCount = (int) (totalVol / largeCap);
            totalVol -= largeCount * largeCap;
        }

        // Then medium
        if (mediumCap > 0) {
            mediumCount = (int) (totalVol / mediumCap);
            totalVol -= mediumCount * mediumCap;
        }

        // Last small
        if (smallCap > 0) {
            smallCount = (int) Math.ceil(totalVol / smallCap);
        }

        System.out.printf(
            "Best Shipping: Large=%d, Medium=%d, Small=%d%n", 
            largeCount, mediumCount, smallCount
        );
    }

    public double shippingPrice() {
        Distance distanceObj = new Distance(); 
        double km = distanceObj.getDistance(destination); 

        double totalGallons = 0;
        for (Item item : items) {
            totalGallons += item.getVolumeGallons();
        }

        double totalRisk = 0;
        for (Item item : items) {
            totalRisk += item.getRiskFactor();
        }
        double avgRisk = items.isEmpty() ? 0.0 : totalRisk / items.size();
        double baseCost = totalGallons * km * 0.01 * (1 + avgRisk);
        double emptyCost = km * 0.6;
        return baseCost + emptyCost;
    }
}